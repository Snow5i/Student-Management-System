<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "sms");

// Add entry
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add'])) {
    $subject = $_POST['subject'];
    $exam_date = $_POST['exam_date'];
    $stmt = $conn->prepare("INSERT INTO exam_timetable (subject, exam_date) VALUES (?, ?)");
    $stmt->bind_param("ss", $subject, $exam_date);
    $stmt->execute();
}

// Delete entry
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM exam_timetable WHERE id=$id");
}

// Fetch all entries
$timetable = $conn->query("SELECT * FROM exam_timetable");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Timetable</title>

 <link rel="stylesheet" href="time_table.css">
</head>
<body>
<div class="container">
    <h2>Exam Timetable (Admin)</h2>

    <form method="POST">
        <input type="text" name="subject" placeholder="Subject Name" required>
        <input type="date" name="exam_date" required>
        <button type="submit" name="add">Add Subject</button>
    </form>

    <table>
        <tr><th>Subject</th><th>Exam Date</th><th>Action</th></tr>
        <?php while($row = $timetable->fetch_assoc()): ?>
            <tr>
                <td><?= $row['subject'] ?></td>
                <td><?= $row['exam_date'] ?></td>
                <td><a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this subject?')">Delete</a></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
</div>
</body>
</html>
