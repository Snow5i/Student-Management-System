<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "sms");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$students = $conn->query("SELECT id, username FROM users WHERE role='student'");
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["student_id"])) {
    $user_id = intval($_POST["student_id"]);

    // Subject names
    $subject1_name = mysqli_real_escape_string($conn, $_POST["subject1_name"] ?? '');
    $subject2_name = mysqli_real_escape_string($conn, $_POST["subject2_name"] ?? '');
    $subject3_name = mysqli_real_escape_string($conn, $_POST["subject3_name"] ?? '');
    $subject4_name = mysqli_real_escape_string($conn, $_POST["subject4_name"] ?? '');
    $subject5_name = mysqli_real_escape_string($conn, $_POST["subject5_name"] ?? '');
    $subject6_name = mysqli_real_escape_string($conn, $_POST["subject6_name"] ?? '');

    // Subject marks
    $marks = [
        intval($_POST["subject1"] ?? 0),
        intval($_POST["subject2"] ?? 0),
        intval($_POST["subject3"] ?? 0),
        intval($_POST["subject4"] ?? 0),
        intval($_POST["subject5"] ?? 0),
        intval($_POST["subject6"] ?? 0),
    ];

    // Check if result exists
    $existing = $conn->query("SELECT id FROM results WHERE user_id = $user_id");
    if ($existing->num_rows > 0) {
        $sql = "UPDATE results SET 
                subject1 = {$marks[0]}, subject2 = {$marks[1]}, subject3 = {$marks[2]},
                subject4 = {$marks[3]}, subject5 = {$marks[4]}, subject6 = {$marks[5]},
                sub1_name = '$subject1_name', sub2_name = '$subject2_name', sub3_name = '$subject3_name',
                sub4_name = '$subject4_name', sub5_name = '$subject5_name', sub6_name = '$subject6_name'
                WHERE user_id = $user_id";
        if ($conn->query($sql)) {
            $message = "Result updated successfully!";
        } else {
            $message = "Error updating result: " . $conn->error;
        }
    } else {
        $sql = "INSERT INTO results (
            user_id, subject1, subject2, subject3, subject4, subject5, subject6,
            sub1_name, sub2_name, sub3_name, sub4_name, sub5_name, sub6_name
        ) VALUES (
            $user_id, {$marks[0]}, {$marks[1]}, {$marks[2]}, {$marks[3]}, {$marks[4]}, {$marks[5]},
            '$subject1_name', '$subject2_name', '$subject3_name', '$subject4_name', '$subject5_name', '$subject6_name'
        )";
        if ($conn->query($sql)) {
            $message = "Result submitted successfully!";
        } else {
            $message = "Error inserting result: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Upload Results</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: whitesmoke;
        }

        .container {
            background: white;
            padding: 30px;
            max-width: 750px;
            margin: 50px auto;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.15);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            background: linear-gradient(to right, #6a11cb, #2575fc);
            color: white;
            padding: 15px;
            border-radius: 8px;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 12px 0 5px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .row {
            display: flex;
            gap: 10px;
        }

        .row > div {
            flex: 1;
        }

        button {
            background:linear-gradient(to right, #6a11cb, #2575fc);
            color: white;
            border: none;
            padding: 14px;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            transition: 0.3s;
        }

        button:hover {
            opacity: 0.9;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            background: #ff5f6d;
            background: linear-gradient(135deg, #5a67d8, #467bc1);
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }

        .message {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Upload Student Results</h2>

    <?php if ($message): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Select Student:</label>
        <select name="student_id" required>
            <option value="">-- Select Student --</option>
            <?php while ($row = $students->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['username']) ?></option>
            <?php endwhile; ?>
        </select>

        <div class="row">
            <div>
                <label>Subject 1 Name:</label>
                <input type="text" name="subject1_name" required>
            </div>
            <div>
                <label>Marks:</label>
                <input type="number" name="subject1" required min="0" max="100">
            </div>
        </div>

        <div class="row">
            <div>
                <label>Subject 2 Name:</label>
                <input type="text" name="subject2_name" required>
            </div>
            <div>
                <label>Marks:</label>
                <input type="number" name="subject2" required min="0" max="100">
            </div>
        </div>

        <div class="row">
            <div>
                <label>Subject 3 Name:</label>
                <input type="text" name="subject3_name" required>
            </div>
            <div>
                <label>Marks:</label>
                <input type="number" name="subject3" required min="0" max="100">
            </div>
        </div>

        <div class="row">
            <div>
                <label>Subject 4 Name:</label>
                <input type="text" name="subject4_name" required>
            </div>
            <div>
                <label>Marks:</label>
                <input type="number" name="subject4" required min="0" max="100">
            </div>
        </div>

        <div class="row">
            <div>
                <label>Subject 5 Name:</label>
                <input type="text" name="subject5_name" required>
            </div>
            <div>
                <label>Marks:</label>
                <input type="number" name="subject5" required min="0" max="100">
            </div>
        </div>

        <div class="row">
            <div>
                <label>Subject 6 Name:</label>
                <input type="text" name="subject6_name" required>
            </div>
            <div>
                <label>Marks:</label>
                <input type="number" name="subject6" required min="0" max="100">
            </div>
        </div>

        <button type="submit">Submit / Update Results</button>
    </form>

    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
</div>

</body>
</html>