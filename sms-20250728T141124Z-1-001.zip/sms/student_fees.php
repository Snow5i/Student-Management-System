<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "sms");

$username = $_SESSION["username"];
$userResult = $conn->query("SELECT id FROM users WHERE username = '$username'");
$user = $userResult->fetch_assoc();
$user_id = $user['id'];

$feeResult = $conn->query("SELECT status FROM fees WHERE user_id = $user_id");
$feeStatus = $feeResult->num_rows > 0 ? $feeResult->fetch_assoc()['status'] : "Fee status not updated yet";
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Fee Status</title>
    
    <style>
        body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #f3f4f6, #e2e8f0);
    margin: 0;
    padding: 40px;
}

.fee-box {
    max-width: 500px;
    margin: 100px auto;
    background: #ffffff; /* white background */
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.fee-box h2 {
    color: #333;
    margin-bottom: 20px;
}

.fee-box .status {
    margin-top: 20px;
    font-size: 24px;
    font-weight: bold;
    color: #0077b6;
}

/* Back to Dashboard Button */
.back-btn {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
    text-decoration: none;
    font-weight: 600;
    font-size: 15px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
    transition: background 0.3s ease, transform 0.2s ease;
}

.back-btn:hover {
    background: linear-gradient(135deg, #5a67d8, #6b46c1);
    transform: translateY(-2px);
}

    </style>
</head>
<body>
    <div class="fee-box">
        <h2>Your Fee Status</h2>
        <div class="status"><?= $feeStatus ?></div>
    </div>
    <a href="student_dashboard.php" class="back-btn">← Back to Dashboard</a>

</body>
</html>
