<?php
include 'db.php'; // MySQL connection

$result = $conn->query("SELECT * FROM academic_calendar ORDER BY event_date ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Academic Calendar - Student View</title>
    <link rel="stylesheet" href="calendar.css">
</head>
<body>
    <div class="container">
        <h2>📘 Academic Calendar</h2>

        <table>
            <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Description</th>
            </tr>

            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo date("d M Y", strtotime($row['event_date'])); ?></td>
                    <td><?php echo htmlspecialchars($row['description']); ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
<a href="student_dashboard.php" class="back-button">← Back to Dashboard</a>

</body>
</html>

<?php
include 'db.php';

$eventsByMonth = [];

// Fetch events from DB
$sql = "SELECT * FROM academic_calendar ORDER BY event_date ASC";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $month = date('F', strtotime($row['event_date']));
    $eventsByMonth[$month][] = $row;
}

$allMonths = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];
?>

