<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /*body {
            font-family: 'Segoe UI', sans-serif;
            background: white;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }*/
        body {
    margin: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: url('admindashboard.jpg') no-repeat center center fixed;
    background-size: cover;
    color: #fff;
        }

.main-content {
    padding: 30px;
    background: rgba(0, 0, 0, 0.5);
    margin-left: 250px;
    min-height: 100vh;
    color: white;
}



        /*.sidebar {
            width: 250px;
            height: 100vh;
            background: linear-gradient(180deg, #6a11cb, #2575fc);
            color: white;
            padding: 20px;
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 10;
        }*/
        .sidebar {
   background: linear-gradient(180deg, #0f2027, #203a43, #2c5364);
    
    color: white;
    position: fixed;
    height: 100%;
    width: 250px;
    padding: 20px;
    overflow-y: auto;
}





        .sidebar h2 {
            margin-bottom: 30px;
            font-size: 24px;
            text-align: center;
        }

        .sidebar a {
            padding: 12px 20px;
            margin: 8px 0;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .logout a {
            background: linear-gradient(to right, #ff9966, #ff5e62);
            color: black;
            font-weight: bold;
        }

        .main-content {
            margin-left: 250px;
            padding: 30px;
            width: calc(100% - 250px);
            overflow-y: auto;
        }

        .main-content h1 {
            font-size: 32px;
            margin-bottom: 10px;
            color: #333;
        }

        .main-content p {
            font-size: 18px;
            margin-bottom: 30px;
            color: #555;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
        }

        .card-content {
            padding: 15px;
        }

        .card-content h3 {
            margin-top: 0;
            font-size: 20px;
            color: #333;
        }

        .card-content p {
            color: #666;
            font-size: 14px;
        }

        marquee {
            margin: 20px 0;
            font-size: 16px;
            color: #333;
            background:  #dfe4ff;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        @media screen and (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: space-around;
            }

            .main-content {
                margin-left: 0;
                width: 100%;
                padding: 20px;
            }
        }



        .sidebar a {
    padding: 12px 20px;
    margin: 8px 0;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    transition: background 0.3s, transform 0.3s, box-shadow 0.3s;
    display: block;
    font-weight: 500;
    position: relative;
}

.sidebar a:hover {
    background: rgba(255, 255, 255, 0.15);
    transform: translateX(8px);
    box-shadow: 0 0 10px rgba(255, 255, 255, 0.4);
    border-left: 4px solid #fff;
}









    </style>
</head>




<body>
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="manage_students.php">📁 Manage Students</a>
        <a href="admin_calendar.php">📅 Academic Calendar</a>
        <a href="admin_timetable.php">⌛ Time Table</a>
        <a href="admin_halltickets.php">📜 Hall Tickets</a>
        <a href="admin_results.php">📑 Results</a>
        <a href="admin_revaluation.php">🖋️ Revaluation</a>
        <a href="admin_fees.php">💳 Fees Management</a>
        <a href="admin_helpdesk.php">📝 Help Desk</a>
        <div class="logout">
            <a href="logout.php">🚪 Logout</a>
        </div>
    </div>
    


    <div class="main-content">
        <h1>Welcome, Admin</h1>
        <p>Manage students, update academic records, view messages, and more from this dashboard.</p>

        <marquee behavior="scroll" direction="left">✨ Welcome to the Student Management System Admin Panel! Keep academic info updated regularly. ✨</marquee>

        <div class="dashboard-grid">
            <div class="card">
                <img src="students.jpg" alt="Manage Students">
                <div class="card-content">
                    <h3>Manage Students</h3>
                    <p>Add, edit or delete student details and keep profiles updated.</p>
                </div>
            </div>
            <div class="card">
                <img src="calander.jpg" alt="Academic Calendar">
                <div class="card-content">
                    <h3>Academic Calendar</h3>
                    <p>Update holidays and academic events for students.</p>
                </div>
            </div>
            <div class="card">
                <img src="hallticket.jpg" alt="Hall Tickets">
                <div class="card-content">
                    <h3>Hall Tickets</h3>
                    <p>Generate and manage student hall tickets with exam schedules.</p>
                </div>
            </div>
            <div class="card">
                <img src="feesadmin.jpg" alt="Fees Management">
                <div class="card-content">
                    <h3>Fees Management</h3>
                    <p>Track student fee status and update payment info.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
