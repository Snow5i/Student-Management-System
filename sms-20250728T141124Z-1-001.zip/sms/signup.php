<?php
$conn = new mysqli("localhost", "root", "", "sms");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];

    $email = $_POST["email"];
    $password = hash('sha256', $_POST["password"]);
    $role = "student";
    $phone = $_POST["phone"];

    $city = $_POST["city"];
    $country = $_POST["country"];

    // Check if username exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE username=? OR email=?");
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role, phone, city, country) VALUES ( ?,?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $username, $email, $password, $role, $phone, $city, $country);
        $stmt->execute();
        echo "<script>alert('Registration Successful'); window.location.href='login.php';</script>";
    } else {
        echo "<script>alert('Username or Email already taken');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Sign Up</title>
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="logo.jpg" alt="Logo">
            <h3>Welcome Back Students</h3>
        </div>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            
            <input type="text" name="phone" placeholder="Phone Number">
            <input type="text" name="city" placeholder="City">
            <input type="text" name="country" placeholder="Country">
            <button type="submit">Sign Up</button>
        </form>
        <a href="login.php">Already have an account? Log in</a>
    </div>
</body>
</html>
