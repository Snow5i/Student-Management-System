<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #f2f4f8;
        }

        .sidebar {
            height: 100vh;
            width: 220px;
            position: fixed;
            top: 0;
            left: 0;
            /*background: linear-gradient(to bottom, #4e54c8, #8f94fb);*/
            background: linear-gradient(180deg, #0f2027, #203a43, #2c5364);
            color: white;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            transition: background 0.3s ease;
        }

        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.2);
            font-weight: bold;
        }

        .logout {
            margin-top: auto;
            padding: 20px;
        }

        .main-content {
            margin-left: 240px;
            padding: 30px;
        }

        .welcome {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .marquee {
            margin: 20px 0;
            background: #dfe4ff;
            padding: 10px;
            border-left: 5px solid #4e54c8;
            color: #333;
            font-weight: bold;
        }

        .gallery {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            width: 280px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: scale(1.03);
        }

        .card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
        }

        .card-content {
            padding: 15px;
        }

        .card-content h4 {
            margin: 0 0 10px;
        }

        .card-content p {
            font-size: 14px;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Student Panel</h2>
        <a href="student_profile.php">🆔 My Profile</a>
        <a href="student_calendar.php">📅 Academic Calendar</a>
        <a href="student_timetable.php">🕒 Timetable</a>
        <a href="student_hallticket.php">📜 Hall Ticket</a>
        <a href="student_results.php">📖 Results</a>
        <a href=" revaluation_request.php">🖋️ Revaluation</a>
        <a href="student_fees.php">💳 Fees</a>
        <a href="student_helpdesk.php">❓ Help Desk</a>
        <div class="logout">
            <a href="logout.php">🚪 Logout</a>
        </div>
    </div>

    <div class="main-content">
        <div class="welcome">
            <h1>Welcome, <?php echo $_SESSION["username"]; ?>! 👋</h1>
            <p>Access your academic details, timetable, results, and more from here.</p>
        </div>

        <div class="marquee">
            <marquee behavior="scroll" direction="left">🎉 Don't forget to check your hall ticket and fee status before exams! Stay prepared and best of luck! 📚</marquee>
        </div>

        <div class="gallery">
            <div class="card">
                <img src="study1.jpg" alt="Study Time">
                <div class="card-content">
                    <h4>Exam Prep Tips</h4>
                    <p>Get ready with effective study strategies tailored to your subjects.</p>
                </div>
            </div>
            <div class="card">
                <img src="library.jpg" alt="Library">
                <div class="card-content">
                    <h4>Library Access</h4>
                    <p>Make use of your digital library access to ace your courses.</p>
                </div>
            </div>
            <div class="card">
                <img src="campus.jpg" alt="Campus">
                <div class="card-content">
                    <h4>Campus Life</h4>
                    <p>Stay updated on campus news, events, and student activities.</p>
                </div>
            </div>
            <div class="card">
                <img src="fees.jpg" alt="Fees">
                <div class="card-content">
                    <h4>Fees Structure</h4>
                    <p>Check Your Fees Updates Seamlessly.</p>
                </div>
            </div>
            <div class="card">
                <img src="helpdesk.jpg" alt="HelpDesk">
                <div class="card-content">
                    <h4>Help-Desk</h4>
                    <p>Need help? We're here to assist, fast!.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

