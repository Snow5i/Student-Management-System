<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "sms");

if (isset($_GET["accept"])) {
    $id = intval($_GET["accept"]);
    $conn->query("UPDATE revaluation_requests SET status='Accepted' WHERE id=$id");
}

$result = $conn->query("
    SELECT r.id, r.subject, r.status, u.username 
    FROM revaluation_requests r
    JOIN users u ON r.user_id = u.id
    ORDER BY r.request_date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Revaluation</title>
    <link rel="stylesheet" href="admin_theme.css">
    <style>
        .container {
            max-width: 900px;
            margin: auto;
            margin-top: 50px;
            background: rgba(255,255,255,0.9);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border: 1.5px solid #333;
        }
        th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
        }
        .accept-btn {
            padding: 6px 15px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            text-decoration: none;
        }
        .accepted {
            color: green;
            font-weight: bold;
        }
        .back-btn {
            margin-top: 20px;
            display: block;
            text-align: center;
            color: #fff;
            background: #007bff;
            padding: 10px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Revaluation Requests</h2>
    <table>
        <tr>
            <th>Student</th>
            <th>Subject</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row["username"]) ?></td>
                <td><?= htmlspecialchars($row["subject"]) ?></td>
                <td><?= $row["status"] === "Accepted" ? "<span class='accepted'>Accepted</span>" : "Pending" ?></td>
                <td>
                    <?php if ($row["status"] !== "Accepted"): ?>
                        <a href="?accept=<?= $row["id"] ?>" class="accept-btn">Accept</a>
                    <?php else: ?>
                        <span class="accepted">✔ Done</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
    <a href="admin_dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
</div>
</body>
</html>
