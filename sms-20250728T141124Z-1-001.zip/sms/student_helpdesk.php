
<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "student") {
header("Location: login.php");
exit();
}
$conn = new mysqli("localhost", "root", "", "sms");

$user_id = $_SESSION["id"];

// Handle message submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["message"])) {
$msg = $conn->real_escape_string($_POST["message"]);
$conn->query("INSERT INTO help_desk (user_id, message) VALUES ($user_id, '$msg')");
}

$result = $conn->query("SELECT * FROM help_desk WHERE user_id = $user_id ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Student Help Desk</title>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f4f7fa;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 900px;
    margin: 40px auto;
    background: #fff;
    padding: 30px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border-radius: 12px;
}

h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #333;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 14px;
    border-bottom: 1px solid #ddd;
    vertical-align: top;
}

th {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    text-align: left;
}

td {
    background-color: #fafafa;
}

textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
    resize: vertical;
    font-size: 14px;
    font-family: inherit;
    margin-bottom: 8px;
}

button {
    background: linear-gradient(135deg, #43cea2, #185a9d);
    color: white;
    padding: 10px 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease, transform 0.2s ease;
}

button:hover {
    background: linear-gradient(135deg, #2bc0e4, #0f2027);
    transform: scale(1.05);
}

form {
    margin: 0;
}
.back-btn {
    display: inline-block;
    margin-bottom: 20px;
    padding: 10px 16px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    transition: background 0.3s ease, transform 0.2s ease;
}

.back-btn:hover {
    background: linear-gradient(135deg, #5a67d8, #6b46c1);
    transform: translateY(-2px);
}



</style>
</head>
<body>
<div class="container">
<h2>Help Desk - Contact Admin</h2>
<form method="POST">
<textarea name="message" placeholder="Type your query or issue here..." required></textarea>
<button type="submit">Send</button>
</form>

<h3>Your Messages</h3>
<table>
<tr><th>Your Message</th><th>Admin Reply</th><th>Date</th></tr>
<?php while ($row = $result->fetch_assoc()): ?>
<tr>
<td><?= htmlspecialchars($row["message"]) ?></td>
<td><?= $row["reply"] ? htmlspecialchars($row["reply"]) : "No reply yet" ?></td>
<td><?= $row["created_at"] ?></td>
</tr>
<?php endwhile; ?>
</table>
</div>
<a href="student_dashboard.php" class="back-btn">← Back to Dashboard</a>

</body>
</html>
