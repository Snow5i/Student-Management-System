<?php
include 'db.php';

$successMsg = "";

// Handle update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $country = $_POST['country'];

    $stmt = $conn->prepare("UPDATE users SET username=?, email=?, phone=?, city=?, country=? WHERE id=? AND role='student'");
    $stmt->bind_param("sssssi", $username, $email, $phone, $city, $country, $id);
    $stmt->execute();
    
    $successMsg = "Student updated successfully!";
}

// Fetch students
$result = $conn->query("SELECT * FROM users WHERE role='student'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Students</title>
    <link rel="stylesheet" href="manage_students.css">
    <style>
        
        .back-btn {
    display: inline-block;
    margin: 20px 0;
    padding: 10px 20px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    transition: background 0.3s ease, transform 0.2s ease;
}

.back-btn:hover {
    background: linear-gradient(135deg, #5a67d8, #6b46c1);
    transform: translateY(-2px);
}

        .success-message {
            background-color: #dff0d8;
            color: #3c763d;
            border: 1px solid #d6e9c6;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    
        <h2>📋 Manage Students</h2>

        <?php if ($successMsg): ?>
            <div class="success-message">
                <?= $successMsg ?>
            </div>
        <?php endif; ?>

        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Phone</th>
                <th>City</th>
                <th>Country</th>
                <th>Actions</th>
            </tr>

            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <form method="POST" action="">
                        <td><?php echo $row['id']; ?></td>
                        <td><input type="text" name="username" value="<?php echo htmlspecialchars($row['username']); ?>"></td>
                        <td><input type="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>"></td>
                        <td><input type="text" name="phone" value="<?php echo htmlspecialchars($row['phone']); ?>"></td>
                        <td><input type="text" name="city" value="<?php echo htmlspecialchars($row['city']); ?>"></td>
                        <td><input type="text" name="country" value="<?php echo htmlspecialchars($row['country']); ?>"></td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="update">Update</button>
                        </td>
                    </form>
                </tr>
            <?php } ?>
        </table>
    </div>
    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>

</body>
</html>
