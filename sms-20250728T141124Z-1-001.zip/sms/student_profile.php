<?php
session_start();
include 'db.php';

// Redirect if not logged in or not student
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['id'];
$query = $conn->prepare("SELECT username, email, phone, city, country FROM users WHERE id = ?");
$query->bind_param("i", $student_id);
$query->execute();
$result = $query->get_result();

if ($result->num_rows == 0) {
    echo "Profile not found.";
    exit();
}

$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <style>
        body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #f3f4f6, #e2e8f0);
    margin: 0;
    padding: 40px;
}

.profile-container {
    margin-left: 270px; /* Adjust to align with your sidebar */
    background-color: #ffffff; /* White background */
    padding: 30px 40px;
    border-radius: 16px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    max-width: 600px;
    position: relative;
}

h2 {
    text-align: center;
    color: #333;
    margin-bottom: 30px;
}

.profile-card p {
    font-size: 18px;
    color: #444;
    padding: 10px 0;
    border-bottom: 1px solid #ddd;
}

.profile-card p strong {
    color: #2b6cb0;
}

/* Stylish Back to Dashboard Button */
.back-button {
    display: inline-block;
    margin-top: 20px;
    background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
    color: white;
    padding: 12px 25px;
    border-radius: 30px;
    text-decoration: none;
    font-weight: bold;
    font-size: 16px;
    box-shadow: 0 5px 12px rgba(0, 0, 0, 0.15);
    transition: all 0.3s ease;
}

.back-button:hover {
    background: linear-gradient(135deg, #2575fc 0%, #6a11cb 100%);
    transform: scale(1.05);
}
</style>

</head>
<body>
    <div class="profile-container">
        <h2>👤 My Profile</h2>
        <div class="profile-card">
            <p><strong>Username:</strong> <?php echo htmlspecialchars($student['username']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
            <p><strong>Phone:</strong> <?php echo htmlspecialchars($student['phone']); ?></p>
            <p><strong>City:</strong> <?php echo htmlspecialchars($student['city']); ?></p>
            <p><strong>Country:</strong> <?php echo htmlspecialchars($student['country']); ?></p>
        </div>
    </div>
    <a href="student_dashboard.php" class="back-button">← Back to Dashboard</a>

</body>
</html>
