<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "sms");

// Update fee status
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_POST["user_id"];
    $status = $_POST["status"];

    // Check if record exists
    $check = $conn->query("SELECT * FROM fees WHERE user_id = $user_id");
    if ($check->num_rows > 0) {
        $conn->query("UPDATE fees SET status = '$status' WHERE user_id = $user_id");
    } else {
        $conn->query("INSERT INTO fees (user_id, status) VALUES ($user_id, '$status')");
    }

    echo "<script>alert('Fee status updated successfully!');</script>";
}

// Fetch all students
$students = $conn->query("SELECT id, username FROM users WHERE role = 'student'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Update Fee Status</title>
    
    <style>
        body {
    font-family: Arial, sans-serif;
    background: #f4f4f4;
    margin: 0;
    padding: 0;
}

.fee-form {
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    background: #ffffff; /* white background */
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}

.fee-form h2 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
}

.fee-form select,
.fee-form input,
.fee-form button {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    font-size: 16px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

.fee-form button {
    background-color: #4CAF50;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease;
}

.fee-form button:hover {
    background-color: #45a049;
}

/* Back to Dashboard Button Styling */
.back-button {
    display: inline-block;
    padding: 10px 25px;
    background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
    color: white;
    text-align: center;
    border: none;
    border-radius: 25px;
    font-weight: bold;
    text-decoration: none;
    margin-top: 20px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.back-button:hover {
    background: linear-gradient(135deg, #2575fc 0%, #6a11cb 100%);
    transform: scale(1.05);
}

    </style>
</head>
<body>
    <div class="fee-form">
        <h2>Update Fee Status</h2>
        <form method="POST">
            <label>Select Student:</label>
            <select name="user_id" required>
                <option value="">-- Select Student --</option>
                <?php while ($row = $students->fetch_assoc()): ?>
                    <option value="<?= $row['id'] ?>"><?= $row['username'] ?></option>
                <?php endwhile; ?>
            </select>

            <label>Fee Status:</label>
            <select name="status" required>
                <option value="Paid">Paid</option>
                <option value="Not Paid">Not Paid</option>
            </select>

            <button type="submit">Update Status</button>
        </form>
    </div>
    <a href="admin_dashboard.php" class="back-button">← Back to Dashboard</a>

</body>
</html>
