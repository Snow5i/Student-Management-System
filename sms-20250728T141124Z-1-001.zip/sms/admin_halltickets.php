<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "sms");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = intval($_POST['user_id']);
    $subjects = $_POST['subject'];
    $dates = $_POST['date'];
    $times = $_POST['time'];

    if (count($subjects) === 6 && count($dates) === 6 && count($times) === 6) {
        // Delete old hall ticket
        $conn->query("DELETE FROM hall_tickets WHERE user_id = $user_id");

        $stmt = $conn->prepare("INSERT INTO hall_tickets (
            user_id,
            subject1, subject1_date, subject1_time,
            subject2, subject2_date, subject2_time,
            subject3, subject3_date, subject3_time,
            subject4, subject4_date, subject4_time,
            subject5, subject5_date, subject5_time,
            subject6, subject6_date, subject6_time
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

         $stmt->bind_param(
           "issssssssssssssssss",

            $user_id,
            $subjects[0], $dates[0], $times[0],
            $subjects[1], $dates[1], $times[1],
            $subjects[2], $dates[2], $times[2],
            $subjects[3], $dates[3], $times[3],
            $subjects[4], $dates[4], $times[4],
            $subjects[5], $dates[5], $times[5]
        );

        if ($stmt->execute()) {
            echo "<script>alert('Hall Ticket created successfully!');</script>";
        } else {
            echo "<script>alert('Error: ".$stmt->error."');</script>";
        }
    } else {
        echo "<script>alert('Please fill all 6 subjects.');</script>";
    }
}

// Fetch students
$students = $conn->query("SELECT id, username FROM users WHERE role='student'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Hall Ticket</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #eef2f3;
        }
        .container {
            max-width: 750px;
            margin: 40px auto;
            padding: 25px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        label, input, select {
            display: block;
            width: 100%;
            margin-bottom: 12px;
        }
        .row {
            display: flex;
            gap: 10px;
        }
        .row > div {
            flex: 1;
        }
        input, select {
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, #5e60ce, #64dfdf);
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background: linear-gradient(to right, #4361ee, #48bfe3);
        }
        .back-btn {
    display: inline-block;
    margin: 20px 0;
    padding: 10px 20px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    transition: background 0.3s ease, transform 0.2s ease;
}

.back-btn:hover {
    background: linear-gradient(135deg, #5a67d8, #6b46c1);
    transform: translateY(-2px);
}

    </style>
</head>
<body>
    <div class="container">
        <h2>Generate Hall Ticket</h2>
        <form method="POST">
            <label for="user_id">Select Student</label>
            <select name="user_id" required>
                <option value="">-- Select Student --</option>
                <?php while($row = $students->fetch_assoc()): ?>
                    <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['username']) ?></option>
                <?php endwhile; ?>
            </select>

            <?php for ($i = 1; $i <= 6; $i++): ?>
                <div class="row">
                    <div>
                        <label>Subject <?= $i ?></label>
                        <input type="text" name="subject[]" placeholder="Subject Name" required>
                    </div>
                    <div>
                        <label>Date</label>
                        <input type="date" name="date[]" required>
                    </div>
                    <div>
                        <label>Time</label>
                        <input type="time" name="time[]" required>
                    </div>
                </div>
            <?php endfor; ?>

            <button type="submit">Generate Hall Ticket</button>
        </form>
    </div>
    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>

</body>
</html>


