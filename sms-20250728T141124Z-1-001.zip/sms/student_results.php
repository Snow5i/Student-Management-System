<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "sms");
$user_id = $_SESSION["id"];
$result = $conn->query("SELECT * FROM results WHERE user_id = $user_id");

if ($result->num_rows === 0) {
    echo "<h2 style='text-align:center; color:red;'>Results not published yet.</h2>";
    exit();
}

$row = $result->fetch_assoc();
$subjects = [
    $row["sub1_name"] => $row["subject1"],
    $row["sub2_name"] => $row["subject2"],
    $row["sub3_name"] => $row["subject3"],
    $row["sub4_name"] => $row["subject4"],
    $row["sub5_name"] => $row["subject5"],
    $row["sub6_name"] => $row["subject6"],
];


$total = array_sum($subjects);
$percentage = round($total / 6, 2);

$grade = "Fail";
$classification = "Fail";
if ($percentage >= 75) {
    $grade = "A+";
    $classification = "Distinction";
} elseif ($percentage >= 60) {
    $grade = "A";
    $classification = "First Class";
} elseif ($percentage >= 50) {
    $grade = "B";
    $classification = "Second Class";
} elseif ($percentage >= 35) {
    $grade = "C";
    $classification = "Pass";
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>My Results</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: whitesmoke;
            margin: 0;
            padding: 40px 20px;
        }

        .marksheet {
            max-width: 850px;
            margin: auto;
            padding: 40px 30px;
            background: #ffffffcc;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            position: relative;
            backdrop-filter: blur(5px);
        }

        .marksheet h2 {
            text-align: center;
            font-size: 30px;
            margin-bottom: 25px;
            color: #333;
            letter-spacing: 1px;
        }

        .marksheet p {
            font-size: 18px;
            margin-bottom: 10px;
            color: #444;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 14px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            font-size: 16px;
        }

        th {
            background-color: #2575fc;;
            color: white;
        }

        .summary {
            margin-top: 30px;
            background: #f9f9f9;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }

        .summary p {
            margin: 10px 0;
            font-size: 17px;
            color: #333;
        }

        .seal, .signature {
            position: absolute;
            bottom: 40px;
            text-align: center;
        }

        .seal {
            left: 30px;
        }

        .signature {
            right: 30px;
        }

        .seal img, .signature img {
            height: 60px;
        }

        .note {
            margin-top: 40px;
            font-style: italic;
            font-size: 14px;
            text-align: center;
            color: #555;
        }

        .back-button {
            display: inline-block;
            margin-bottom: 30px;
            padding: 12px 25px;
            background: #2575fc;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .back-button:hover {
            background: #6a11cb;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <div class="marksheet">
        <a href="student_dashboard.php" class="back-button">← Back to Dashboard</a>
        <h2>Student Marksheet</h2>
        <p><strong>Student:</strong> <?= $_SESSION["username"] ?></p>
        
        <table>
            <tr><th>Subject</th><th>Marks</th></tr>
            <?php foreach ($subjects as $subject => $marks): ?>
                <tr><td><?= $subject ?></td><td><?= $marks ?></td></tr>
            <?php endforeach; ?>
        </table>

        <div class="summary">
            <p><strong>Total:</strong> <?= $total ?> / 600</p>
            <p><strong>Percentage:</strong> <?= $percentage ?>%</p>
            <p><strong>Grade:</strong> <?= $grade ?></p>
            <p><strong>Result:</strong> <?= $classification ?></p>
        </div>

        <div class="seal">
            <img src="seal.png" alt="Seal"><br>
            <span>Institution Seal</span>
        </div>
        <div class="signature">
            <img src="sig.jpg" alt="Signature"><br>
            <span>Controller of Examinations</span>
        </div>

        <div class="note">
            *This is a system-generated marksheet and does not require physical signature.
        </div>
    </div>
</body>
</html>
