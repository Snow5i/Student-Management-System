<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "sms");
$timetable = $conn->query("SELECT * FROM exam_timetable ORDER BY exam_date ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Exam Timetable</title>
    <link rel="stylesheet" href="time_table.css">
</head>
<body>
<div class="container">
    <h2>Your Exam Timetable</h2>
    <table>
        <tr><th>Subject</th><th>Date</th></tr>
        <?php while($row = $timetable->fetch_assoc()): ?>
            <tr>
                <td><?= $row['subject'] ?></td>
                <td><?= $row['exam_date'] ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <a href="student_dashboard.php">← Back to Dashboard</a>
</div>
</body>
</html>
