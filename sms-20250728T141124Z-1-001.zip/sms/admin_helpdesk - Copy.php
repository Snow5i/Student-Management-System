<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "sms");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["reply"], $_POST["id"])) {
    $reply = $conn->real_escape_string($_POST["reply"]);
    $id = (int) $_POST["id"];
    if ($conn->query("UPDATE help_desk SET reply = '$reply' WHERE id = $id")) {
        $_SESSION["reply_success"] = "Reply successfully sent!";
    }
    header("Location: " . $_SERVER["PHP_SELF"]); // Prevent form resubmission
    exit();
}

$queries = $conn->query("SELECT h.id, u.username, h.message, h.reply, h.created_at FROM help_desk h JOIN users u ON h.user_id = u.id ORDER BY h.created_at DESC");
?>



<!DOCTYPE html>
<html>
<head>
    <title>Admin Help Desk</title>
    <style>
        


        body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f4f7fa;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 900px;
    margin: 40px auto;
    background: #fff;
    padding: 30px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border-radius: 12px;
}

h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #333;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 14px;
    border-bottom: 1px solid #ddd;
    vertical-align: top;
}

th {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    text-align: left;
}

td {
    background-color: #fafafa;
}

textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
    resize: vertical;
    font-size: 14px;
    font-family: inherit;
    margin-bottom: 8px;
}

button {
    background: linear-gradient(135deg, #43cea2, #185a9d);
    color: white;
    padding: 10px 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease, transform 0.2s ease;
}

button:hover {
    background: linear-gradient(135deg, #2bc0e4, #0f2027);
    transform: scale(1.05);
}

form {
    margin: 0;
}



.success-msg {
    background-color: #d4edda;
    color: #155724;
    padding: 12px 16px;
    border: 1px solid #c3e6cb;
    border-radius: 6px;
    margin-bottom: 20px;
    font-weight: bold;
}

.back-btn {
    display: inline-block;
    margin-bottom: 20px;
    padding: 10px 16px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    transition: background 0.3s ease, transform 0.2s ease;
}

.back-btn:hover {
    background: linear-gradient(135deg, #5a67d8, #6b46c1);
    transform: translateY(-2px);
}







    </style>
</head>
<body>
    <div class="container">
        <h2>Help Desk - Student Queries</h2>
        <table>
            <tr><th>Student</th><th>Message</th><th>Reply</th><th>Date</th></tr>
            <?php while ($row = $queries->fetch_assoc()): ?>
                <tr>
                    <td><?= $row["username"] ?></td>
                    <td><?= htmlspecialchars($row["message"]) ?></td>
                    <td>
                        <form method="POST">
                            <textarea name="reply" required><?= htmlspecialchars($row["reply"] ?? '') ?></textarea>
                            <input type="hidden" name="id" value="<?= $row["id"] ?>">
                            <button type="submit">Send Reply</button>
                        </form>
                    </td>
                    <td><?= $row["created_at"] ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
        <?php if (isset($_SESSION["reply_success"])): ?>
    <div class="success-msg"><?= $_SESSION["reply_success"] ?></div>
    <?php unset($_SESSION["reply_success"]); ?>
<?php endif; ?>

    </div>
    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>

</body>
</html>
