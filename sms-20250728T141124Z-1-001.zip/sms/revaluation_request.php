<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "sms");

$user_id = $_SESSION["id"];
$submitted = false;

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["subject"])) {
    $subject = $conn->real_escape_string($_POST["subject"]);
    $conn->query("INSERT INTO revaluation_requests (user_id, subject) VALUES ($user_id, '$subject')");
    $submitted = true;
}

$result = $conn->query("SELECT * FROM revaluation_requests WHERE user_id = $user_id ORDER BY request_date DESC");
$latest = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Revaluation Request</title>
    <link rel="stylesheet" href="student_theme.css"> <!-- link to your styled theme -->
    <style>
        .container {
            max-width: 700px;
            margin: auto;
            margin-top: 50px;
            background: rgba(255,255,255,0.85);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            margin-top: 20px;
            text-align: center;
        }
        select, button {
            padding: 10px;
            margin: 10px;
            width: 60%;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        .status {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
            color: green;
        }
        .back-btn {
            display: block;
            margin: 30px auto 0;
            padding: 10px 25px;
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: #fff;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Revaluation Request Form</h2>

    <?php if ($submitted): ?>
        <div class="status">Your request has been submitted successfully!</div>
    <?php endif; ?>

    <form method="POST">
        <label for="subject">Select Subject for Revaluation:</label><br>
        <select name="subject" required>
            <option value="">--Choose Subject--</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Science">Science</option>
            <option value="English">English</option>
            <option value="History">History</option>
            <option value="Computer Science">Computer Science</option>
        </select><br>
        <button type="submit">Submit Request</button>
    </form>

    <?php if ($latest): ?>
        <div class="status">
            <strong>Latest Request:</strong><br>
            Subject: <?= $latest['subject'] ?><br>
            Status: <?= $latest['status'] === 'Accepted' ? '✅ Accepted — will update in few days' : '⏳ Pending' ?>
        </div>
    <?php endif; ?>

    <a href="student_dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
</div>
</body>
</html>
