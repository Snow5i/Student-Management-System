<?php
// db.php should have your database connection
include 'db.php';

// Handle Add Event
if (isset($_POST['add'])) {
    $title = $_POST['title'];
    $event_date = $_POST['event_date'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO academic_calendar (title, event_date, description) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $event_date, $description);
    $stmt->execute();
    header("Location: admin_calendar.php");
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM academic_calendar WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: admin_calendar.php");
}

// Handle Update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $event_date = $_POST['event_date'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("UPDATE academic_calendar SET title=?, event_date=?, description=? WHERE id=?");
    $stmt->bind_param("sssi", $title, $event_date, $description, $id);
    $stmt->execute();
    header("Location: admin_calendar.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Academic Calendar - Admin</title>
    <link rel="stylesheet" href="calendar.css">
</head>
<body>
    <div class="container">
        <h2>📅 Academic Calendar - Admin Panel</h2>

        <!-- Add Event Form -->
        <form method="post" class="form">
            <input type="text" name="title" placeholder="Event Title" required>
            <input type="date" name="event_date" required>
            <textarea name="description" placeholder="Description"></textarea>
            <button type="submit" name="add">Add Event</button>
        </form>

        <!-- Event Table -->
        <table>
            <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>

            <?php
            $result = $conn->query("SELECT * FROM academic_calendar ORDER BY event_date ASC");
            while ($row = $result->fetch_assoc()) {
            ?>
                <tr>
                    <form method="post">
                        <td><input type="text" name="title" value="<?php echo $row['title']; ?>"></td>
                        <td><input type="date" name="event_date" value="<?php echo $row['event_date']; ?>"></td>
                        <td><textarea name="description"><?php echo $row['description']; ?></textarea></td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="update">Update</button>
                            <a href="admin_calendar.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Delete this event?')">Delete</a>
                        </td>
                    </form>
                </tr>
            <?php } ?>
        </table>
    </div>
    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
</body>
</html>


